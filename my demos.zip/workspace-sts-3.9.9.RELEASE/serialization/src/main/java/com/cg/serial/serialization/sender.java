package com.cg.serial.serialization;

import java.io.*;

public class sender{
	
	public static void main(String args[]) throws IOException {
		
		File file=new File("C:\\Users\\Admin\\Desktop\\mycloud\\serial.txt");
		FileOutputStream output= new FileOutputStream(file);
		
		ObjectOutputStream object=new ObjectOutputStream(output);
		Person person=new Person(3);
		object.writeObject(person);
		object.close();
		output.close();
		
	}

}
