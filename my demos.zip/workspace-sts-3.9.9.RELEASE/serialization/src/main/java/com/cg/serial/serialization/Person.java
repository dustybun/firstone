package com.cg.serial.serialization;

import java.io.Serializable;

public class Person implements Serializable
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 4;
int i;

@Override
public String toString() {
	return "person [i=" + i + "]";
}

public int getI() {
	return i;
}

public void setI(int i) {
	this.i = i;
}

public Person() {
	super();
	// TODO Auto-generated constructor stub
}
public Person(int i) {
	this.i=i;
	// TODO Auto-generated constructor stub
}
}
