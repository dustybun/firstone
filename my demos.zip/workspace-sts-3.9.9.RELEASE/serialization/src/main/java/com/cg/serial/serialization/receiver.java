package com.cg.serial.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class receiver {
public static void main(String args[]) throws IOException, ClassNotFoundException {
		
		File file=new File("C:\\Users\\Admin\\Desktop\\mycloud\\serial.txt");
		FileInputStream output= new FileInputStream(file);
		
		ObjectInputStream object=new ObjectInputStream(output);
		Person person=new Person();
		person=(Person)object.readObject();
		System.out.println(person);
		object.close();
		output.close();
		
	}

}
