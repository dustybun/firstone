package fabseries;
class A{
A(){
  System.out.println("a");
 }
 A(String a){
  System.out.println("A");
 }
}
class B extends A {
 B(){
  System.out.println("b");//
 }
 B(String a){
  System.out.println("B");
 }
}

public class Test  {
  
 public static void go(){
  new B();
 }
 public static void main(String [] args) {
 go();
 }
}