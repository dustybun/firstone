package com.cg.demojunit5.test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.*;
 import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.demojunit5.service.CalculatorService;
import com.cg.demojunit5.service.CalculatorServiceImpl;

class calculatorTest {

CalculatorService service;
	
	
	@BeforeEach //this will run before each case   // Marker annotation
	public void beforeTest() {
		service=new CalculatorServiceImpl();
		
	}
	
	@Test
	public void myTest(){ 
		assertEquals(new Double(30.0),service.addNumber(10.0, 20.0));
		assertEquals(new Double(20.0), service.subNumber(40.0, 20.0));
		assertEquals(new Double(8.0), service.mulNumber(4.0, 2.0));
		assertEquals(new Double(2.0), service.divNumber(40.0, 20.0));
	}
	@Test//(expected=ArithmeticException.class)
	public void myTestOne() {
		assertThrows(ArithmeticException.class,()->{
			
		service.divNumber(40.0, 0.0);
		
	});}
	
	@AfterEach  // we havhis after each test
	public void afterTest() {
		service=null;
		
	}
}
