package com.cg.hashmap.dto;

public class Department {

}
