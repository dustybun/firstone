package com.cg.employeemanagement.service;

import com.cg.employeemanagement.dto.Employee;

public interface EmployeeService {

	public Employee addEmployee(Employee emp);
	public Employee[] showEmployee();
	public Employee searchEmployee(Employee emp);
	public Employee deleteEmployee(Employee emp);
	public Employee[] updateEmployee();
}
