package com.cg.employeemanagement.service;

import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao dao=new EmployeeDaoImpl();
	
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}
	public Employee[] showEmployee() {
		// TODO Auto-generated method stub
		return dao.showEmployee();
	}
	
	public Employee deleteEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(emp)
				;
	}
	public Employee[] updateEmployee() {
		// TODO Auto-generated method stub
		return dao.updateEmployee();
	}
	public Employee searchEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.searchEmployee(emp);
	}
	

}
