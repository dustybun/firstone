package com.cg.employeemanagement.dao;

import com.cg.employeemanagement.dto.Employee;

public interface EmployeeDao {
	
	public Employee addEmployee(Employee emp);
	public Employee[] showEmployee();
	public Employee searchEmployee(Employee emp);
	public Employee deleteEmployee(Employee emp);
	public Employee[] updateEmployee();


}
