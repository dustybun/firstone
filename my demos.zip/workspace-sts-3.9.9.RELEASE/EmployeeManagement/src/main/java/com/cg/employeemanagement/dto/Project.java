package com.cg.employeemanagement.dto;

import java.math.BigDecimal;

public class Project {
	
	private Integer projId;
	private String projName;
	private BigDecimal projCost;
	private Employee Employees;
	
	public Project() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Project(Integer projId, String projName, BigDecimal projCost, Employee employees) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.projCost = projCost;
		Employees = employees;
	}



	@Override
	public String toString() {
		return "Project [projId=" + projId + ", projName=" + projName + ", projCost=" + projCost + ", Employees="
				+ Employees + "]";
	}



	public Integer getProjId() {
		return projId;
	}

	public void setProjId(Integer projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public BigDecimal getProjCost() {
		return projCost;
	}

	public void setProjCost(BigDecimal projCost) {
		this.projCost = projCost;
	}

	public Employee getEmployees() {
		return Employees;
	}

	public void setEmployees(Employee employees) {
		Employees = employees;
	}
	
	
	
	

}
