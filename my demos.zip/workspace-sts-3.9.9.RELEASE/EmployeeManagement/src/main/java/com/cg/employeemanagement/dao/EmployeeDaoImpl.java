package com.cg.employeemanagement.dao;

import com.cg.employeemanagement.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Employee empArray[]=new Employee[5];

	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		this.empArray[0]=emp;
		return emp;
	}

	public Employee[] showEmployee() {
		// TODO Auto-generated method stub
		return this.empArray;
	}

	public Employee searchEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return emp ;
	}

	public Employee deleteEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return emp;
	}

	public Employee[] updateEmployee() {
		// TODO Auto-generated method stub
		return this.empArray;
	}
	
	

}
