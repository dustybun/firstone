package com.cg.demoone.service;

public class project extends Employee implements a,b{
@Override
public void getLogin() {
	
}
@Override
public void getLogout() {
	
}
	@Override
	public void addNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double subtractNumber(double numOne, double numTwo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showData() {
		// TODO Auto-generated method stub
		super.showData();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	
	
}
