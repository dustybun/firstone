package com.cg.demoone.service;

public interface a extends b{
	public int id=10; //public static final int id=10
	public void addNumber(); //public abstract void addnumber();
	public double subtractNumber(double numOne,double numTwo);
	
}
