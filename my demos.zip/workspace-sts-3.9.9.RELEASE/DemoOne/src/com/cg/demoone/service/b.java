package com.cg.demoone.service;

public interface b {
	public void getData();
	public void showData();

}
