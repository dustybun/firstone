package com.cg.demoone.service;

public abstract class Employee {
	public abstract void getData(); // abstract method
	
	public void showData() {
		//non abstract method
		System.out.println("non-abstract method.. ");
	}

}
