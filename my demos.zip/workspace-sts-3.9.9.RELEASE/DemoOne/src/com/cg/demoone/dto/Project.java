package com.cg.demoone.dto;

//child/sub class of Employee
public class Project extends Employee {
	
	
	/*public Project() {
		System.out.println("In project constructor...");
	}

	public Project(String name) {
		System.out.println("In ProjectPara Constructor...");
	}*/
	
	//public void getData() {
		//System.out.println(empId);
	//}
	
	
	
}
