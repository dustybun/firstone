package com.cg.demoone.dto;

public class Employee {
	 
	/*public int empId;  
	public Employee() {
		System.out.println("In Employee contructor...");
	}
	public Employee(int i) {
		System.out.println("Parameterized Constructor..."+i);
	}
	//public void getData() {
		//System.out.println("In Employee GetData");
	//}
	public void getData(int id) {
		System.out.println("In Employee GetData"+id);
	}
	public void getData(int id,String name ) {
		System.out.println("In Employee GetData"+id+ " "+name);
		
	}
	public int getData() {
		System.out.println("In Employee GetData");
		return 0;
		
	}5*/
	
	public static int pf;
	public int data;
	 
	 private int empId;
	 private String empName;
	 private double empSalary;
	 private String empDepartment;
	 
	 static{
			System.out.println("emp static block");
			}
	 
	 public Employee() {
		 System.out.println("in conj");
	 }
	 public int getEmpId() {
		 return empId;
		}
	 public void setEmpId(int empId) {
		 this.empId=empId;
	 }
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDepartment="
				+ empDepartment + "]";
	}
}
