package com.cg.demoone.ui;
//import java.util.Scanner;
//import java.util.regex.Pattern;

//import com.cg.demoone.dto.*;
//import com.cg.demoone.service.Project1;
import com.cg.demoone.service.Employee;
public class MyApplication {
	
	/*static int empId;
	public MyApplication(int Id) {

	}
	public static void getData() {
	
		//new MyApplication().showData(); 
		empId++;
	}
	public void showData() {
		System.out.println(empId);
		//getData();
		
	}*/
	
	public static void main(String[] args) {
		String a="abc";
		StringBuffer sb=new StringBuffer("abc");
		sb.append("bbb");
		System.out.println(sb);
		//Employee emp=new Project1();
		//emp.getData();
		//emp.showData();
		
		
		
		//System.out.println(empId);
	
		//getData();
		//new MyApplication().showData();
		
		//getData();
		//MyApplication my=new MyApplication();
		//my.nonStatic();
		//new Employee();  
		
		
		//new Employee(10);
		//new Employee();
		
		/*Project pro=new Project("ABCD");
		pro.getData();
		pro.empId=1001;
		
	
	Employee emp=new Employee();
	emp.getData(10);
	emp.getData(11, "qwer");
	
	}*/
		/*Scanner scr=new Scanner(System.in);
		
		System.out.println("Enter employee id");
		int eid=scr.nextInt();
		System.out.println("Enter employee name");
		scr.nextLine();
		String ename=scr.nextLine();
		System.out.println("Enter employee salary");
		Double esal=scr.nextDouble();
		System.out.println("Enter employee department");
		String edep=scr.next();
	
		
		
		Employee emp=new Employee();
		emp.setEmpId(eid);
		emp.setEmpName(ename);
		emp.setEmpSalary(esal);
		emp.setEmpDepartment(edep);
		
		Employee.pf=12344; // ref static var
		emp.data=999; // ref instance variable
		
		
		/*System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpSalary());
		System.out.println(emp.getEmpDepartment());*/
		
		
		/*System.out.println(emp);
		
		Employee empOne=new Employee();
		System.out.println(empOne);
		System.out.println(empOne.data);
		System.out.println(empOne.pf);*/
}
	/*static{
		System.out.println(" in static block");
		}*/
	}
