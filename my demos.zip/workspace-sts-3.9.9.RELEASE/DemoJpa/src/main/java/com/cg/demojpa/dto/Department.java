package com.cg.demojpa.dto;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="jpa_deparment")
public class Department {
	@Id
	private Integer deptId;
	private String deptName;
	
	@OneToMany
	@JoinColumn(name="emp_id")
	private List<Employee> empList;

	public Integer getDeptId() {
		return deptId;
	}

	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public Department(Integer deptId, String deptName, List<Employee> empList) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.empList = empList;
	}

	public Department() {
	
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", empList=" + empList + "]";
	}
	
	

}
