package com.cg.demojpa.ui;

//import java.math.BigDecimal;
//import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.List;
import java.util.Scanner;

import com.cg.demojpa.dto.Address;
import com.cg.demojpa.dto.Department;
import com.cg.demojpa.dto.Employee;
import com.cg.demojpa.dto.Project;
import com.cg.demojpa.service.EmployeeService;
import com.cg.demojpa.service.EmployeeServiceImpl;

public class EmployeeMain {

	public static EmployeeServiceImpl service = new EmployeeService();
	public static Scanner sc =new Scanner(System.in);
	
	public EmployeeMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws ParseException {
		System.out.println("Enter id");
		int id = sc.nextInt();
		System.out.println("Enter name");
		sc.nextLine();
		String name = sc.nextLine();
		System.out.println("Enter the salary");
		double salary = sc.nextDouble();
		System.out.println("Enter the Date");
		String date=sc.next();
		SimpleDateFormat st=new SimpleDateFormat("yyyy/mm/dd");
		Date dateNew=st.parse(date);
		
		System.out.println("Enter City");
		String city=sc.next();
		System.out.println("Enter State");
		String state=sc.next();
		System.out.println("Enter the PinCode");
		int pincode=sc.nextInt();
		
		System.out.println("Enter project id");
		int pid = sc.nextInt();
		System.out.println("Enter project name");
		sc.nextLine();
		String pname = sc.nextLine();
		System.out.println("Enter the project cost");
		double pcost = sc.nextDouble();
		
		System.out.println("Enter department id");
		int deptId = sc.nextInt();
		System.out.println("Enter department name");
		sc.nextLine();
		String deptName = sc.nextLine();
		
		Employee emp = new Employee();
		Address addr=new Address();
		Project pro=new Project();
		Department dep=new Department();
		
		dep.setDeptId(deptId);
		dep.setDeptName(deptName);
		
		addr.setCity(city);
		addr.setState(state);
		addr.setPincode(pincode);
		
		emp.setEmpId(id);
		emp.setEmpName(name);
		emp.setEmpSalary(salary);
		emp.setDateOfJoining(dateNew);
		emp.setAddr(addr);
		emp.setDep(dep);
		
		pro.setProjId(pid);
		pro.setProjName(pname);
		pro.setProjCost(pcost);
		emp.setProj(pro);
		service.addEmployee(emp);
		
		//service.removeEmployee(emp);
	}}
	