package com.cg.demotwo.dto;

public class Employee {
	
	public double add(int x) throws ArithmeticException {
		if(x==0) {
			throw new ArithmeticException("galat");
		}
		return (10/0+x);
		

	//public static void setEmpId(int empId) {
		// TODO Auto-generated method stub
		/*this.empId=empId;
	}

	public int getEmpId() {
		// TODO Auto-generated method stub
		return EmpId;*/
	
	
	}

}
