package com.cg.demotwo.ui;
import java.io.FileInputStream;
import java.io.IOException;

import org.omg.CORBA.portable.InputStream;

import com.cg.demotwo.dto.Employee;
public class MyApplication {
	//static Employee emp;
	public static void main(String args[]) {
		
		Employee emp=new
		
		//  null point Exception emp=new Employee();
		//emp.setEmpId(1001);
		// System.out.println(emp.getEmpId());
		/*int a[]= {10,20,30};
		
		
				
				try {
					
					System.out.println(a[2]);
					int aa=10/0;
					System.out.println(aa);
					
					
				}catch(ArrayIndexOutOfBoundsException e) {
					System.out.println("Problem in array");
				} 
				catch(ArithmeticException ae) {
					System.out.println("Divide by zero");
				}finally {
					System.out.println("Always..");
				}
					System.out.println("aSDAS");*/
		
		
	}
}
