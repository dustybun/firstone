package com.cg.democollection.dto;

public class manager {
	
	

}
