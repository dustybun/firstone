package com.cg.democollection.service;

import java.util.Comparator;

import com.cg.democollection.dto.Employee;

public class NameComparator<T,K> implements Comparator<Employee<T,K>> {

	public int compare(Employee<T, K> o1, Employee<T, K> o2) {
		// TODO Auto-generated method stub
		return o1.getEmpName().compareTo(o2.getEmpName());
	}
	

}
