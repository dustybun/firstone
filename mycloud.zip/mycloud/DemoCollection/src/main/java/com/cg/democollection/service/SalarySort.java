package com.cg.democollection.service;

import java.util.Comparator;

import com.cg.democollection.dto.Employee;

public class SalarySort<T,K> implements Comparator <Employee<T,K>> {

	public int compare(Employee<T, K> o1, Employee<T, K> o2) {
		if((Double)o1.getEmpSalary()>(Double)o2.getEmpSalary())
		// TODO Auto-generated method stub
		return -1;
		 
		
		else if((Double)o1.getEmpSalary()<(Double)o2.getEmpSalary())
			// TODO Auto-generated method stub
			return 1;
		else	return 0;
	}
	
	

}
