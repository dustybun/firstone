
package com.cg.democollection.ui;

import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import com.cg.democollection.dto.Employee;
import com.cg.democollection.service.EmployeeService;
import com.cg.democollection.service.EmployeeServiceImpl;
import com.cg.democollection.service.NameComparator;
import com.cg.democollection.service.SalarySort;

public class MyApplication<T>{


	public static void main(String args[]) {
		Scanner scr=new Scanner(System.in);
		EmployeeService service=new EmployeeServiceImpl();
		int choice;
		do {
			
		printall();
		
		System.out.println("Enter your choice = ");
		choice=scr.nextInt();
		switch(choice) {
		case 1:
	
		System.out.println("Enter Employee id =");
		Integer Id=scr.nextInt();
		System.out.println("Enter Employee name =");
		String name=scr.next();
		System.out.println("Enter Employee Salary =");
		Double Salary=scr.nextDouble();
		
		
		Employee<Integer,Double> emp=new Employee<Integer,Double>();
		emp.setEmpId(Id);
		emp.setEmpName(name);
		emp.setEmpSalary(Salary);
		
		service.addEmployee(emp);
		break;
		
		case 2: 
			List<Employee<Integer,Double>>myList=service.showEmployee();
			//Comparator<? super Employee<Integer, Double>> Comparator = null;
			//Collections.sort(myList/*Comparator*/);
			Collections.sort(myList, new NameComparator());
			for(Employee<Integer,Double> employee : myList) {
			System.out.println("Employee Id is"+employee.getEmpId());
			System.out.println("Employee Name is" +employee.getEmpName());
			System.out.println("Employee Salary is" +employee.getEmpSalary());
			}
			
			Collections.sort(myList, new SalarySort());
			for(Employee<Integer,Double> employee : myList) {
			System.out.println("Employee Id is"+employee.getEmpId());
			System.out.println("Employee Name is" +employee.getEmpName());
			System.out.println("Employee Salary is" +employee.getEmpSalary());
			}
		break;
		
		case 3: System.exit(0);
		}}while(choice!=3);
	}
		
		
		public static void  printall() {
			System.out.println("Press 1 to add \n   Press 2 to see your list \n press 3 to Exit" );
			
		}}

		

		//MyApplication<Integer> d=new MyApplication<Integer>(15);
		//System.out.println(d.getDetails());
		//Employee<Integer,Double> empOne = new Employee<Integer,Double>();
		
		//empOne.setEmpId(1001);
		///Employee<String,Double> empTwo = new Employee<String, Double>();
		//empTwo.setEmpId("rrrr");
		//}
/*List<Integer> myList=new LinkedList<Integer>();
myList.add(1);
myList.add(3);
myList.add(5);
myList.add(2);myList.add(76);myList.add(69);

System.out.println(myList.size());
System.out.println(myList);
System.out.println("_____________________");
for(Integer integer : myList) {
	System.out.println(integer);
	
}
for(int i=0;i<myList.size();i++) {
	System.out.println(myList.get(i));
	System.out.println("_____________________");
	System.out.println(myList.indexOf(5));
	System.out.println(myList.lastIndexOf(99));
}
	*/

