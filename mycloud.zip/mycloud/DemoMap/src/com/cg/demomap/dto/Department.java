package com.cg.demomap.dto;

public class Department {

}
