package com.cg.demomap.dto;

public class Project {
	// one project can have Many employee 
	Employee emp;
	private int projId;
	private String projName;
	private proj
	Map<,Employee>

}