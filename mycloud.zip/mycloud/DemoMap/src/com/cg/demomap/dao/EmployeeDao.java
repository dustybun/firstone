package com.cg.demomap.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.demomap.dto.Employee;

public interface EmployeeDao {

	
	public Employee<?,?> addEmployee(Employee<?,?> emp);
	public HashMap<?,?> showEmployee();
	
	

}

