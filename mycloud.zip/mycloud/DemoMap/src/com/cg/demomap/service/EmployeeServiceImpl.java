package com.cg.demomap.service;

import java.util.HashMap;
import java.util.List;

import com.cg.demomap.dao.EmployeeDaoImpl;
import com.cg.demomap.dto.Employee;
import com.cg.demomap.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDaoImpl dao = new EmployeeDaoImpl();

	public Employee<?, ?> addEmployee(Employee<?, ?> emp) throws EmployeeException{
	
		if ((double)emp.getEmpSalary() <=0.0)
		{
			throw new EmployeeException("Sal cannot be less than 0");
		}
		return dao.addEmployee(emp);
	}

	public HashMap<?,?> showEmployee() {
		// TODO Auto-generated method stub
		return dao.showEmployee();
	}
	

}


