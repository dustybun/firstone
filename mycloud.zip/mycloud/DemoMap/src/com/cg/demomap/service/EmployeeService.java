package com.cg.demomap.service;

import java.util.HashMap;

import com.cg.demomap.dto.Employee;
import com.cg.demomap.exception.EmployeeException;

public interface EmployeeService {
	public Employee<?,?> addEmployee(Employee<?,?> emp) throws EmployeeException ;
	public HashMap<?,?> showEmployee();
	}



