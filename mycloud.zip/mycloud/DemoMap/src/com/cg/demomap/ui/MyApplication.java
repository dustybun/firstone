package com.cg.demomap.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.comparatorName;
import com.cg.demomap.dto.comparatorSal;
import com.cg.demomap.service.EmployeeServiceImpl;

public class MyApplication {
	
	public static void printDetail() {
		System.out.println("1 for Add");
		System.out.println("2 for show");
	}
	
	public static void main(String[] args) {
		int choice;

		EmployeeServiceImpl service = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {

			printDetail();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
			System.out.println("Enter the id");
			Integer id = sc.nextInt();
			System.out.println("Enter the name");
			String name = sc.next();
			System.out.println("Enter the salary");
			Double sal = sc.nextDouble();
			Employee<Integer, Double> emp = new Employee<Integer, Double>();
			
			emp.setEmpId(id);
			emp.setEmpName(name);
			emp.setEmpSalary(sal);
			try {
				service.addEmployee(emp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			
				break;

			case 2:
				HashMap<Long,Employee<?, ?>> myMap = (HashMap<Long, Employee<?, ?>>) service.showEmployee();
				List<Employee<?, ?>> myList = new ArrayList<Employee<?,?>>(myMap.values());
				Collections.sort(myList, new comparatorSal());
				System.out.println("Sort by Salary");
				for (Employee<?, ?> employee : myList) {
					System.out.println("ID"+employee.getEmpId());
					System.out.println("Name"+employee.getEmpName());
					System.out.println("Salary"+employee.getEmpSalary());
				}
				Collections.sort(myList, new comparatorName());
				System.out.println("Sort by Name");
				for (Employee<?, ?> employee : myList) {
					System.out.println("ID"+employee.getEmpId());
					System.out.println("Name"+employee.getEmpName());
					System.out.println("Salary"+employee.getEmpSalary());
				}
				break;
				
			}
		} while (choice !=3);
		sc.close();


}


}
