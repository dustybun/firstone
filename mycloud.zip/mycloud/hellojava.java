class Hello
{
	public static void main(String args[])
	{
	String empName=args[0];
	String empId=args[1];
	String empSal=args[2];
	System.out.println(empName+" is the Employee name");
	System.out.println(empId+" is the Employee ID");
	System.out.println(empSal+" is the Employee Salary");
	int empSalary=Integer.parseInt(empSal);

	if(empSalary>=5000)
	{
		System.out.println("No Rise in Salary reqired");
	}
	else if(empSalary<5000)
	{
		System.out.println("Eligible for 10% rise in salary");
	}
	}
}