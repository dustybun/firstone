class parse
{
	public static void main(String args[])
	{
		String empName=args[0];
		String empId=args[1];
		String empSal=args[2];
		System.out.println("Name is " +empName+  "Id is " +empId+ "Salary is " +empSal);
		double empSalary=Double.parseDouble(empSal);
		
		if(empSalary<5000)
		{	
			empSalary=empSalary*0.1;
			System.out.println("Rise in salary by 10%" +empSalary);
		}
		else 
		if(empSalary>5000 && empSalary<7000)
		{
			empSalary=empSalary*0.05;
			System.out.println("Rise in salary by 5%" +empSalary);
		}
		else 			
		if(empSalary>7000)
		{
			System.out.println("No need of rise in Salary");
		}
		}
}
			