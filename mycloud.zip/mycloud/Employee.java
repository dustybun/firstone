class Employee{
int empId;
String empName;
double empSalary;
String empDepartment;

public void getLogin(){
System.out.println("IN Login");
}

public void getLogout(){
System.out.println("In Logout");
}
public String getName(){
return "Hello :" +empName;
}
public double getIncreasedSalary(){
return (0.5*empSalary)+empSalary;
}
public Employee printAllDetails(){
emp.setEmployee(emp)

System.out.println(empone.empId);

}}