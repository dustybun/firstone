class MyApplication{

public static void main(String args[]){

Employee emp=new Employee();

emp.empId=Integer.parseInt(args[0]);
emp.empName=args[1];
emp.empSalary=Double.parseDouble(args[2]);
emp.empDepartment=args[3];
emp.getLogin();
emp.getLogout();
String name=emp.getName();
double salary=emp.getIncreasedSalary();
System.out.println(name+" "+salary);

public void setEmployee(Employee emp){
emp.empId++;
emp.empName="Hello " +emp.emName;
empOne=emp;

}

Employee empone=emp.printAllDetails(){
return empOne;
}
}}